# Legacy Action SLLM (Single Model)

단일 decoder-only Transformer 1개로 prediction, command, reason을 생성하고,
API 응답 시 accuracy를 함께 반환합니다.

## 설치
pip install -r requirements.txt

## 실행 전
set PYTHONPATH=src

## 토크나이저 학습
python -m sllm.tokenizer.train_tokenizer --train_file sample_data/train.jsonl --valid_file sample_data/valid.jsonl --output_dir artifacts/tokenizer --vocab_size 4000

## 모델 학습
python -m sllm.train.train_decoder --train_file sample_data/train.jsonl --valid_file sample_data/valid.jsonl --tokenizer_dir artifacts/tokenizer --config_file configs/model_dev.yaml --output_dir artifacts/model_dev

## 평가
python -m sllm.train.evaluate --valid_file sample_data/valid.jsonl --tokenizer_dir artifacts/tokenizer --model_dir artifacts/model_dev

## API
uvicorn sllm.api.server:app --host 0.0.0.0 --port 8000
