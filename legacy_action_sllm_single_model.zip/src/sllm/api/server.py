import os
from fastapi import FastAPI
from pydantic import BaseModel
from sllm.infer.predict import LegacyActionSLLM

MODEL_DIR = os.environ.get("SLLM_MODEL_DIR", "artifacts/model_dev")
TOKENIZER_DIR = os.environ.get("SLLM_TOKENIZER_DIR", MODEL_DIR)

app = FastAPI(title="Legacy Action SLLM API")
engine = None

class InferRequest(BaseModel):
    legacy_input: dict | str

@app.on_event("startup")
def startup():
    global engine
    engine = LegacyActionSLLM(model_dir=MODEL_DIR, tokenizer_dir=TOKENIZER_DIR)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/infer")
def infer(req: InferRequest):
    return engine.predict(req.legacy_input)
