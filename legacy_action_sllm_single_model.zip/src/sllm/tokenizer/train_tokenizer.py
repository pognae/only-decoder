import argparse, os
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.pre_tokenizers import ByteLevel
from tokenizers.trainers import BpeTrainer
from tokenizers.normalizers import NFD, Lowercase, StripAccents, Sequence
from tokenizers.decoders import ByteLevel as ByteLevelDecoder
from sllm.common.io import read_jsonl, flatten_legacy_input
from sllm.common.modeling import SPECIAL_TOKENS

def iter_texts(files):
    for path in files:
        for row in read_jsonl(path):
            yield flatten_legacy_input(row["legacy_input"])
            yield row["prediction"]
            yield row["command"]
            yield row["reason"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_file", required=True)
    ap.add_argument("--valid_file", required=True)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--vocab_size", type=int, default=8000)
    args = ap.parse_args()

    tokenizer = Tokenizer(BPE(unk_token=SPECIAL_TOKENS["unk_token"]))
    tokenizer.normalizer = Sequence([NFD(), Lowercase(), StripAccents()])
    tokenizer.pre_tokenizer = ByteLevel()
    tokenizer.decoder = ByteLevelDecoder()
    trainer = BpeTrainer(
        vocab_size=args.vocab_size,
        special_tokens=[
            SPECIAL_TOKENS["pad_token"],
            SPECIAL_TOKENS["bos_token"],
            SPECIAL_TOKENS["eos_token"],
            SPECIAL_TOKENS["unk_token"],
        ],
    )
    tokenizer.train_from_iterator(iter_texts([args.train_file, args.valid_file]), trainer=trainer)
    os.makedirs(args.output_dir, exist_ok=True)
    tokenizer.save(os.path.join(args.output_dir, "tokenizer.json"))
    print("saved:", os.path.join(args.output_dir, "tokenizer.json"))

if __name__ == "__main__":
    main()
