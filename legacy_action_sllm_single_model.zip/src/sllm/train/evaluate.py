import argparse, os
from datasets import load_dataset
from transformers import AutoModelForCausalLM
from sllm.common.modeling import load_tokenizer
from sllm.common.prompting import build_inference_prompt, parse_json_fragment
from sllm.common.io import write_json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--valid_file", required=True)
    ap.add_argument("--tokenizer_dir", required=True)
    ap.add_argument("--model_dir", required=True)
    args = ap.parse_args()

    tokenizer = load_tokenizer(args.tokenizer_dir)
    model = AutoModelForCausalLM.from_pretrained(args.model_dir)
    model.eval()
    ds = load_dataset("json", data_files={"validation": args.valid_file})["validation"]

    total, pred_ok, cmd_ok = 0, 0, 0
    for row in ds:
        prompt = build_inference_prompt(row["legacy_input"])
        inputs = tokenizer(prompt, return_tensors="pt")
        outputs = model.generate(**inputs, max_new_tokens=128, do_sample=False, eos_token_id=tokenizer.eos_token_id)
        text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        parsed = parse_json_fragment(text)
        total += 1
        if parsed.get("prediction") == row["prediction"]:
            pred_ok += 1
        if parsed.get("command") == row["command"]:
            cmd_ok += 1

    metrics = {
        "total": total,
        "prediction_accuracy": round(pred_ok / total, 4) if total else 0.0,
        "command_accuracy": round(cmd_ok / total, 4) if total else 0.0,
    }
    out_path = os.path.join(args.model_dir, "metrics.json")
    write_json(out_path, metrics)
    print(metrics)
    print("saved:", out_path)

if __name__ == "__main__":
    main()
