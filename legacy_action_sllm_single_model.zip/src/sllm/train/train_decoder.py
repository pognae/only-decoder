import argparse
from dataclasses import dataclass
from typing import Dict, List
from datasets import load_dataset
from transformers import TrainingArguments, Trainer
from sllm.common.modeling import build_model_from_config, load_tokenizer
from sllm.common.prompting import build_prompt, build_target

@dataclass
class JsonDataCollator:
    tokenizer: object
    label_pad_token_id: int = -100

    def __call__(self, features: List[Dict]):
        import torch
        max_len = max(len(f["input_ids"]) for f in features)
        pad_id = self.tokenizer.pad_token_id
        input_ids, attention_mask, labels = [], [], []
        for f in features:
            pad_len = max_len - len(f["input_ids"])
            input_ids.append(f["input_ids"] + [pad_id] * pad_len)
            attention_mask.append(f["attention_mask"] + [0] * pad_len)
            labels.append(f["labels"] + [self.label_pad_token_id] * pad_len)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_file", required=True)
    ap.add_argument("--valid_file", required=True)
    ap.add_argument("--tokenizer_dir", required=True)
    ap.add_argument("--config_file", required=True)
    ap.add_argument("--output_dir", required=True)
    args = ap.parse_args()

    tokenizer = load_tokenizer(args.tokenizer_dir)
    model, cfg = build_model_from_config(args.config_file)
    train_cfg = cfg["training"]
    model.resize_token_embeddings(len(tokenizer))

    ds = load_dataset("json", data_files={"train": args.train_file, "validation": args.valid_file})
    max_length = train_cfg["max_length"]

    def preprocess(example):
        prompt = build_prompt(example)
        target = build_target(example) + tokenizer.eos_token
        prompt_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        target_ids = tokenizer(target, add_special_tokens=False)["input_ids"]
        input_ids = (prompt_ids + target_ids)[:max_length]
        labels = ([-100] * len(prompt_ids) + target_ids)[:max_length]
        attention_mask = [1] * len(input_ids)
        return {"input_ids": input_ids, "labels": labels, "attention_mask": attention_mask}

    tokenized = ds.map(preprocess, remove_columns=ds["train"].column_names)

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        learning_rate=float(train_cfg["learning_rate"]),
        num_train_epochs=float(train_cfg["num_train_epochs"]),
        per_device_train_batch_size=int(train_cfg["per_device_train_batch_size"]),
        per_device_eval_batch_size=int(train_cfg["per_device_eval_batch_size"]),
        gradient_accumulation_steps=int(train_cfg["gradient_accumulation_steps"]),
        logging_steps=int(train_cfg["logging_steps"]),
        save_steps=int(train_cfg["save_steps"]),
        eval_steps=int(train_cfg["eval_steps"]),
        evaluation_strategy="steps",
        save_strategy="steps",
        warmup_ratio=float(train_cfg["warmup_ratio"]),
        weight_decay=float(train_cfg["weight_decay"]),
        fp16=True,
        report_to=[],
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["validation"],
        data_collator=JsonDataCollator(tokenizer),
    )
    trainer.train()
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print("saved model:", args.output_dir)

if __name__ == "__main__":
    main()
