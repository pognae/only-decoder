import json
from sllm.common.io import flatten_legacy_input

SYSTEM_PROMPT = (
    "You are a legacy action sllm. "
    "Read the full legacy input and output only one valid JSON object. "
    "The JSON must contain prediction, command, and reason."
)

def build_prompt(record: dict) -> str:
    legacy_text = flatten_legacy_input(record["legacy_input"])
    return f"{SYSTEM_PROMPT}\n### LEGACY_INPUT\n{legacy_text}\n### OUTPUT_JSON\n"

def build_target(record: dict) -> str:
    return json.dumps({
        "prediction": record["prediction"],
        "command": record["command"],
        "reason": record["reason"],
    }, ensure_ascii=False)

def build_inference_prompt(legacy_input) -> str:
    legacy_text = flatten_legacy_input(legacy_input)
    return f"{SYSTEM_PROMPT}\n### LEGACY_INPUT\n{legacy_text}\n### OUTPUT_JSON\n"

def parse_json_fragment(text: str) -> dict:
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return {"prediction":"UNKNOWN","command":"NO_ACTION","reason":text.strip()}
    chunk = text[start:end+1]
    try:
        return json.loads(chunk)
    except Exception:
        return {"prediction":"UNKNOWN","command":"NO_ACTION","reason":chunk}
