import json
from typing import Any, Dict

def flatten_legacy_input(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return " | ".join(f"{k}={value[k]}" for k in sorted(value.keys()))
    return json.dumps(value, ensure_ascii=False, sort_keys=True)

def read_jsonl(path: str):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)

def write_json(path: str, obj: Dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
