import os, json
from transformers import AutoModelForCausalLM
from sllm.common.modeling import load_tokenizer
from sllm.common.prompting import build_inference_prompt, parse_json_fragment

class LegacyActionSLLM:
    def __init__(self, model_dir: str, tokenizer_dir: str = None):
        self.model_dir = model_dir
        self.tokenizer_dir = tokenizer_dir or model_dir
        self.tokenizer = load_tokenizer(self.tokenizer_dir)
        self.model = AutoModelForCausalLM.from_pretrained(model_dir)
        self.model.eval()
        self.metrics = {}
        mp = os.path.join(model_dir, "metrics.json")
        if os.path.exists(mp):
            with open(mp, "r", encoding="utf-8") as f:
                self.metrics = json.load(f)

    def predict(self, legacy_input):
        prompt = build_inference_prompt(legacy_input)
        inputs = self.tokenizer(prompt, return_tensors="pt")
        outputs = self.model.generate(**inputs, max_new_tokens=128, do_sample=False, eos_token_id=self.tokenizer.eos_token_id)
        text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        parsed = parse_json_fragment(text)
        parsed["accuracy"] = {
            "prediction_accuracy": self.metrics.get("prediction_accuracy"),
            "command_accuracy": self.metrics.get("command_accuracy"),
        }
        return parsed
